IELTS P2 Gemini visual redesign pack
=====================================
Source: mai4211-netizen/learn / ielts-part2-memory-2026q4/
Source Git revision: 7b69a534aa0369e813328008b0f731551eefa0cf

Editable:
- editable/nice-editorial.css   (It's Nice That theme)
- editable/style.css            (default styling)

Reference ONLY:
- reference/index.html
- reference/site-tabs.css
- reference/compact-v43.css
- reference/feedback-v41.css

Instructions:
1. Change only the two editable CSS files.
2. Keep all original selectors, class names, IDs, JavaScript behavior, layout interactions and responsive functionality.
3. No edits to HTML, JS, question content, audio logic or personal bold records.
4. Send back both complete CSS files, not snippets.
5. Keep rules scoped to the proper themes; avoid touching Part 1 / Part 3.
6. Gemini may request additional files if it needs a true full-page preview; this package contains only the visual CSS and index references.

Files are taken directly from the repository without modification.
